# Tanishk AI
Clean Java-only Android voice assistant MVP.

Features: SpeechRecognizer, TextToSpeech, Gemini REST API, and permitted AccessibilityService actions.

Build: copy local.properties.example to local.properties, add GEMINI_API_KEY, then build debug APK.
For GitHub Actions create repository secret GEMINI_API_KEY.

Android does not allow unrestricted phone control. Accessibility requires explicit user permission. Do not ship a permanent API key in a production APK.
