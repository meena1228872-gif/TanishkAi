# TanishkAI

Voice-controlled Android assistant using Android SpeechRecognizer, TextToSpeech, AccessibilityService and Gemini API.

## GitHub Actions

The build expects a GitHub Actions repository secret named `GEMINI_API_KEY`.
The workflow writes that secret to `local.properties` at build time. `app/build.gradle` reads `local.properties` and exposes the value as `BuildConfig.GEMINI_API_KEY`.

Do not commit a real API key to the repository.

## Local build

Copy `local.properties.example` to `local.properties` and set:

`GEMINI_API_KEY=YOUR_KEY`

Then build the debug APK with Gradle.

## Accessibility

After installing the APK, open the app and enable its Accessibility Service from Android Accessibility settings to allow phone-control actions.
